processGoogleToken({
  newToken: "",
  validLifetimeSecs: 300,
  freshLifetimeSecs: 300,
  "1p_jar": "2022-12-30-07",
  pucrd: "",
});
