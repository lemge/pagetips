(function (omidGlobal) {
  "use strict";
  var n;
  function aa(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function p(a) {
    var b =
      "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    return b ? b.call(a) : { next: aa(a) };
  }
  function q(a) {
    if (!(a instanceof Array)) {
      a = p(a);
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      a = c;
    }
    return a;
  }
  var ba =
      "function" == typeof Object.create
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    ca;
  if ("function" == typeof Object.setPrototypeOf) ca = Object.setPrototypeOf;
  else {
    var da;
    a: {
      var ea = { X: !0 },
        fa = {};
      try {
        fa.__proto__ = ea;
        da = fa.X;
        break a;
      } catch (a) {}
      da = !1;
    }
    ca = da
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ha = ca;
  function r(a, b) {
    a.prototype = ba(b.prototype);
    a.prototype.constructor = a;
    if (ha) ha(a, b);
    else
      for (var c in b)
        if ("prototype" != c)
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
  }
  function ia(a) {
    a = [
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
      a,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    return globalThis;
  }
  var u = ia(this),
    v =
      "function" == typeof Object.defineProperties
        ? Object.defineProperty
        : function (a, b, c) {
            a != Array.prototype && a != Object.prototype && (a[b] = c.value);
          };
  function x(a, b) {
    if (b) {
      var c = u;
      a = a.split(".");
      for (var d = 0; d < a.length - 1; d++) {
        var e = a[d];
        e in c || (c[e] = {});
        c = c[e];
      }
      a = a[a.length - 1];
      d = c[a];
      b = b(d);
      b != d &&
        null != b &&
        v(c, a, { configurable: !0, writable: !0, value: b });
    }
  }
  x("globalThis", function (a) {
    return a || u;
  });
  function y(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  var ja =
    "function" == typeof Object.assign
      ? Object.assign
      : function (a, b) {
          for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d) for (var e in d) y(d, e) && (a[e] = d[e]);
          }
          return a;
        };
  x("Object.assign", function (a) {
    return a || ja;
  });
  function ka() {
    ka = function () {};
    u.Symbol || (u.Symbol = la);
  }
  function na(a, b) {
    this.a = a;
    v(this, "description", { configurable: !0, writable: !0, value: b });
  }
  na.prototype.toString = function () {
    return this.a;
  };
  var la = (function () {
    function a(c) {
      if (this instanceof a) throw new TypeError("Symbol is not a constructor");
      return new na("jscomp_symbol_" + (c || "") + "_" + b++, c);
    }
    var b = 0;
    return a;
  })();
  function z() {
    ka();
    var a = u.Symbol.iterator;
    a || (a = u.Symbol.iterator = u.Symbol("Symbol.iterator"));
    "function" != typeof Array.prototype[a] &&
      v(Array.prototype, a, {
        configurable: !0,
        writable: !0,
        value: function () {
          return oa(aa(this));
        },
      });
    z = function () {};
  }
  function oa(a) {
    z();
    a = { next: a };
    a[u.Symbol.iterator] = function () {
      return this;
    };
    return a;
  }
  x("WeakMap", function (a) {
    function b(h) {
      this.a = (g += Math.random() + 1).toString();
      if (h) {
        h = p(h);
        for (var k; !(k = h.next()).done; ) (k = k.value), this.set(k[0], k[1]);
      }
    }
    function c() {}
    function d(h) {
      var k = typeof h;
      return ("object" === k && null !== h) || "function" === k;
    }
    function e(h) {
      if (!y(h, l)) {
        var k = new c();
        v(h, l, { value: k });
      }
    }
    function f(h) {
      var k = Object[h];
      k &&
        (Object[h] = function (m) {
          if (m instanceof c) return m;
          e(m);
          return k(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var h = Object.seal({}),
            k = Object.seal({}),
            m = new a([
              [h, 2],
              [k, 3],
            ]);
          if (2 != m.get(h) || 3 != m.get(k)) return !1;
          m.delete(h);
          m.set(k, 4);
          return !m.has(h) && 4 == m.get(k);
        } catch (t) {
          return !1;
        }
      })()
    )
      return a;
    var l = "$jscomp_hidden_" + Math.random();
    f("freeze");
    f("preventExtensions");
    f("seal");
    var g = 0;
    b.prototype.set = function (h, k) {
      if (!d(h)) throw Error("Invalid WeakMap key");
      e(h);
      if (!y(h, l)) throw Error("WeakMap key fail: " + h);
      h[l][this.a] = k;
      return this;
    };
    b.prototype.get = function (h) {
      return d(h) && y(h, l) ? h[l][this.a] : void 0;
    };
    b.prototype.has = function (h) {
      return d(h) && y(h, l) && y(h[l], this.a);
    };
    b.prototype.delete = function (h) {
      return d(h) && y(h, l) && y(h[l], this.a) ? delete h[l][this.a] : !1;
    };
    return b;
  });
  x("Map", function (a) {
    function b() {
      var g = {};
      return (g.D = g.next = g.head = g);
    }
    function c(g, h) {
      var k = g.a;
      return oa(function () {
        if (k) {
          for (; k.head != g.a; ) k = k.D;
          for (; k.next != k.head; )
            return (k = k.next), { done: !1, value: h(k) };
          k = null;
        }
        return { done: !0, value: void 0 };
      });
    }
    function d(g, h) {
      var k = h && typeof h;
      "object" == k || "function" == k
        ? f.has(h)
          ? (k = f.get(h))
          : ((k = "" + ++l), f.set(h, k))
        : (k = "p_" + h);
      var m = g.b[k];
      if (m && y(g.b, k))
        for (g = 0; g < m.length; g++) {
          var t = m[g];
          if ((h !== h && t.key !== t.key) || h === t.key)
            return { id: k, list: m, index: g, o: t };
        }
      return { id: k, list: m, index: -1, o: void 0 };
    }
    function e(g) {
      this.b = {};
      this.a = b();
      this.size = 0;
      if (g) {
        g = p(g);
        for (var h; !(h = g.next()).done; ) (h = h.value), this.set(h[0], h[1]);
      }
    }
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var g = Object.seal({ x: 4 }),
            h = new a(p([[g, "s"]]));
          if (
            "s" != h.get(g) ||
            1 != h.size ||
            h.get({ x: 4 }) ||
            h.set({ x: 4 }, "t") != h ||
            2 != h.size
          )
            return !1;
          var k = h.entries(),
            m = k.next();
          if (m.done || m.value[0] != g || "s" != m.value[1]) return !1;
          m = k.next();
          return m.done ||
            4 != m.value[0].x ||
            "t" != m.value[1] ||
            !k.next().done
            ? !1
            : !0;
        } catch (t) {
          return !1;
        }
      })()
    )
      return a;
    z();
    var f = new WeakMap();
    e.prototype.set = function (g, h) {
      g = 0 === g ? 0 : g;
      var k = d(this, g);
      k.list || (k.list = this.b[k.id] = []);
      k.o
        ? (k.o.value = h)
        : ((k.o = {
            next: this.a,
            D: this.a.D,
            head: this.a,
            key: g,
            value: h,
          }),
          k.list.push(k.o),
          (this.a.D.next = k.o),
          (this.a.D = k.o),
          this.size++);
      return this;
    };
    e.prototype.delete = function (g) {
      g = d(this, g);
      return g.o && g.list
        ? (g.list.splice(g.index, 1),
          g.list.length || delete this.b[g.id],
          (g.o.D.next = g.o.next),
          (g.o.next.D = g.o.D),
          (g.o.head = null),
          this.size--,
          !0)
        : !1;
    };
    e.prototype.clear = function () {
      this.b = {};
      this.a = this.a.D = b();
      this.size = 0;
    };
    e.prototype.has = function (g) {
      return !!d(this, g).o;
    };
    e.prototype.get = function (g) {
      return (g = d(this, g).o) && g.value;
    };
    e.prototype.entries = function () {
      return c(this, function (g) {
        return [g.key, g.value];
      });
    };
    e.prototype.keys = function () {
      return c(this, function (g) {
        return g.key;
      });
    };
    e.prototype.values = function () {
      return c(this, function (g) {
        return g.value;
      });
    };
    e.prototype.forEach = function (g, h) {
      for (var k = this.entries(), m; !(m = k.next()).done; )
        (m = m.value), g.call(h, m[1], m[0], this);
    };
    e.prototype[Symbol.iterator] = e.prototype.entries;
    var l = 0;
    return e;
  });
  x("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) y(b, d) && c.push(b[d]);
          return c;
        };
  });
  x("Set", function (a) {
    function b(c) {
      this.a = new Map();
      if (c) {
        c = p(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.a.size;
    }
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(p([c]));
          if (
            !d.has(c) ||
            1 != d.size ||
            d.add(c) != d ||
            1 != d.size ||
            d.add({ x: 4 }) != d ||
            2 != d.size
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            4 != f.value[0].x ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (l) {
          return !1;
        }
      })()
    )
      return a;
    z();
    b.prototype.add = function (c) {
      c = 0 === c ? 0 : c;
      this.a.set(c, c);
      this.size = this.a.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.a.delete(c);
      this.size = this.a.size;
      return c;
    };
    b.prototype.clear = function () {
      this.a.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.a.has(c);
    };
    b.prototype.entries = function () {
      return this.a.entries();
    };
    b.prototype.values = function () {
      return this.a.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.a.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  x("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  x("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  var A = {
      ia: "loaded",
      oa: "start",
      ea: "firstQuartile",
      ja: "midpoint",
      pa: "thirdQuartile",
      ca: "complete",
      ka: "pause",
      ma: "resume",
      ba: "bufferStart",
      aa: "bufferFinish",
      na: "skipped",
      qa: "volumeChange",
      la: "playerStateChange",
      $: "adUserInteraction",
    },
    pa = { fa: "full", da: "domain", ha: "limited" };
  function B(a, b) {
    this.x = null != a.x ? a.x : a.left;
    this.y = null != a.y ? a.y : a.top;
    this.width = a.width;
    this.height = a.height;
    this.B = this.x + this.width;
    this.C = this.y + this.height;
    this.v = a.v || void 0;
    this.T = a.T || [];
    this.b = a.friendlyObstructionClass || void 0;
    this.c = a.friendlyObstructionPurpose || void 0;
    this.f = a.friendlyObstructionReason || void 0;
    this.K = void 0 !== a.K ? !0 === a.K : !0;
    this.g = void 0 !== a.hasWindowFocus ? !0 === a.hasWindowFocus : !0;
    this.w = a.w || void 0;
    this.V = a.V || void 0;
    this.J = a.J || [];
    this.L = a.L || !1;
    this.a = b;
  }
  function qa(a) {
    var b = {};
    return (b.width = a.width), (b.height = a.height), b;
  }
  function C(a) {
    var b = {};
    return Object.assign({}, qa(a), ((b.x = a.x), (b.y = a.y), b));
  }
  function E(a) {
    var b = C(a),
      c = {};
    return Object.assign({}, b, ((c.endX = a.B), (c.endY = a.C), c));
  }
  B.prototype.O = function (a) {
    if (null == a) return !1;
    a = C(a);
    var b = a.y,
      c = a.width,
      d = a.height;
    return (
      this.x === a.x && this.y === b && this.width === c && this.height === d
    );
  };
  function F(a) {
    return a.width * a.height;
  }
  function I(a) {
    return 0 === a.width || 0 === a.height;
  }
  function ra(a, b) {
    var c = 0;
    if (0 < b.length) {
      var d = sa(a, b);
      a = d.Y;
      d = d.Z;
      for (var e = 0; e < a.length - 1; e++)
        for (
          var f = (a[e] + (a[e] + 1)) / 2, l = a[e + 1] - a[e], g = 0;
          g < d.length - 1;
          g++
        ) {
          for (
            var h = (d[g] + (d[g] + 1)) / 2, k = d[g + 1] - d[g], m = !1, t = 0;
            t < b.length;
            t++
          ) {
            var w = C(b[t]);
            if (w.x < f && w.x + w.width > f && w.y < h && w.y + w.height > h) {
              m = !0;
              break;
            }
          }
          m && (c += Math.round(l) * Math.round(k));
        }
    }
    return c;
  }
  function sa(a, b) {
    a = C(a);
    for (var c = [], d = [], e = 0; e < b.length; e++) {
      var f = C(b[e]);
      f = ta(a, f);
      ua(c, f.x);
      ua(c, f.B);
      ua(d, f.y);
      ua(d, f.C);
    }
    c = c.sort(function (l, g) {
      return l - g;
    });
    d = d.sort(function (l, g) {
      return l - g;
    });
    return { Y: c, Z: d };
  }
  function ta(a, b) {
    return {
      x: Math.max(a.x, b.x),
      y: Math.max(a.y, b.y),
      B: Math.min(a.x + a.width, b.x + b.width),
      C: Math.min(a.y + a.height, b.y + b.height),
    };
  }
  function ua(a, b) {
    -1 === a.indexOf(b) && a.push(b);
  }
  function va() {
    this.b = this.a = this.c = this.i = void 0;
    this.l = 0;
    this.h = [];
    this.s = [];
    this.m = 0;
    this.j = [];
    this.f = [];
    this.g = [];
  }
  va.prototype.O = function (a) {
    return null == a ? !1 : JSON.stringify(wa(this)) === JSON.stringify(wa(a));
  };
  function wa(a) {
    var b = [],
      c = [],
      d = {
        viewport: a.i,
        adView: { percentageInView: a.l, pixelsInView: a.m, reasons: a.g },
        declaredFriendlyObstructions: a.h.length,
      };
    if (void 0 !== a.a) {
      d.adView.geometry = C(a.a);
      d.adView.geometry.pixels = F(a.a);
      d.adView.onScreenGeometry = C(a.b);
      d.adView.onScreenGeometry.pixels = Math.max(0, F(a.b) - ra(a.b, a.f));
      for (var e = 0; e < a.f.length; e++) b.push(C(a.f[e]));
      for (e = 0; e < a.s.length; e++) {
        var f = a.s[e],
          l = f,
          g = {};
        l.b && (g.obstructionClass = l.b);
        l.c && (g.obstructionPurpose = l.c);
        l.f && (g.obstructionReason = l.f);
        f = ta(a.a, f);
        c.push(
          Object.assign(
            {},
            { x: f.x, y: f.y, width: f.B - f.x, height: f.C - f.y },
            g
          )
        );
      }
      d.adView.onScreenGeometry.obstructions = b;
      d.adView.onScreenGeometry.friendlyObstructions = c;
    }
    return d;
  }
  function xa(a, b) {
    b = qa(b);
    a.i = {};
    a.i.width = b.width;
    a.i.height = b.height;
    a.c = {};
    a.c.x = 0;
    a.c.y = 0;
    a.c.width = b.width;
    a.c.height = b.height;
    a.c.endX = b.width;
    a.c.endY = b.height;
  }
  function ya() {
    return { x: 0, y: 0, endX: 0, endY: 0, width: 0, height: 0 };
  }
  function za(a, b) {
    var c = {};
    c.x = Math.max(a.x, b.x);
    c.y = Math.max(a.y, b.y);
    c.endX = Math.min(a.endX, b.endX);
    c.endY = Math.min(a.endY, b.endY);
    c.width = Math.max(0, c.endX - c.x);
    c.height = Math.max(0, c.endY - c.y);
    return c;
  }
  function Aa(a, b) {
    return 0.01 < b.width - a.width || 0.01 < b.height - a.height;
  }
  function Ba(a) {
    if (-1 !== a.g.indexOf("backgrounded")) (a.l = 0), (a.m = 0);
    else {
      var b = F(a.a);
      if (0 !== b) {
        var c = Math.max(0, F(a.b) - ra(a.b, a.f));
        a.l = Math.round((c / b) * 100);
        a.m = c;
      }
    }
  }
  function Ca(a, b) {
    if (I(b) || !a.b) b = !1;
    else {
      var c = E(a.b),
        d = c.y,
        e = c.endX;
      a = c.endY;
      var f = b.B;
      c = c.x;
      (f = f < c || 0.01 > Math.abs(f - c)) ||
        ((f = b.x), (f = f > e || 0.01 > Math.abs(f - e)));
      (e = f) || ((e = b.C), (e = e < d || 0.01 > Math.abs(e - d)));
      (d = e) || ((b = b.y), (d = b > a || 0.01 > Math.abs(b - a)));
      b = !d;
    }
    return b;
  }
  function J(a, b) {
    for (var c = !1, d = 0; d < a.g.length; d++) a.g[d] === b && (c = !0);
    c || a.g.push(b);
  }
  function Da(a, b, c, d) {
    var e = b.L ? !0 : b.v === d;
    if (e) {
      c.a = b;
      var f = E(c.a);
      a = za(c.c, f);
      var l = c.a;
      "notAttached" === l.w || "noWindowFocus" === l.w || "noAdView" === l.w
        ? (J(c, "notFound"), (c.b = new B(ya(), !1)))
        : ((l = c.a),
          "viewInvisible" === l.w ||
          "viewGone" === l.w ||
          "viewNotVisible" === l.w ||
          "viewAlphaZero" === l.w ||
          "viewHidden" === l.w ||
          void 0 !== c.a.w ||
          I(c.a)
            ? (J(c, "hidden"), (c.b = new B(ya(), !1)))
            : (c.a.g || (J(c, "backgrounded"), J(c, "noWindowFocus")),
              Aa(a, f) && J(c, "clipped"),
              (c.b = new B(a, !1))));
    } else if (
      ((f = !0), b.a && (f = -1 !== b.T.indexOf(d) ? !1 : !1 === b.K), f)
    ) {
      l = b.J;
      for (var g = 0; g < l.length; g++)
        (f = void 0 !== c.a), Da(a, new B(l[g], f), c, d);
    }
    e ||
      void 0 === c.a ||
      (b.a
        ? -1 !== b.T.indexOf(d)
          ? c.h.push(b)
          : c.j.push(b)
        : ((e = E(b)),
          (d = E(c.b)),
          C(c.b),
          !I(c.b) &&
            b.K &&
            ((b = za(d, e)),
            Aa(b, d) && (J(c, "clipped"), (c.b = new B(b, !1))))));
  }
  function Ea(a, b) {
    this.y = this.x = 0;
    this.width = a;
    this.height = b;
  }
  function Fa() {
    return {
      apiVersion: "1.0",
      accessMode: "limited",
      environment: "web",
      omidJsInfo: { omidImplementer: "omsdk", serviceVersion: "1.4.1-google8" },
      adSessionType: "html",
      supports: ["clid", "vlid"],
    };
  }
  function Ga() {
    this.v = null;
    this.c = Fa();
    this.m = null;
    this.l = "foregrounded";
    this.i = this.j = "none";
    this.h =
      this.g =
      this.f =
      this.s =
      this.b =
      this.a =
      this.I =
      this.N =
        null;
    this.G = !0;
    this.u = new Map();
    this.H = null;
  }
  var K;
  function L() {
    K || (K = new Ga());
    return K;
  }
  function Ha() {
    K.v = null;
    K.c = Fa();
    K.m = null;
    K.U = void 0;
    K.ga = void 0;
    K.S = null;
    K.M = null;
    K.F = null;
    K.l = "foregrounded";
    K.j = "none";
    K.i = "none";
    K.N = null;
    K.I = null;
    K.a = null;
    K.b = null;
    K.s = null;
    K.f = null;
    K.g = null;
    K.h = null;
    K.G = !0;
    K.u = new Map();
    K.H = null;
  }
  var M = (function () {
    if ("undefined" !== typeof omidGlobal && omidGlobal) return omidGlobal;
    if ("undefined" !== typeof global && global) return global;
    if ("undefined" !== typeof window && window) return window;
    if ("undefined" !== typeof globalThis && globalThis) return globalThis;
    var a = Function("return this")();
    if (a) return a;
    throw Error("Could not determine global object context.");
  })();
  function Ia(a) {
    if (a === M) return !1;
    try {
      if ("undefined" === typeof a.location.hostname) return !0;
    } catch (b) {
      return !0;
    }
    return !1;
  }
  function Ja() {
    var a = omidGlobal;
    if (null == a || "undefined" === typeof a.top || null == a.top) return null;
    try {
      var b = a.top;
      return Ia(b) ? null : b.location.href;
    } catch (c) {
      return null;
    }
  }
  function Ka(a, b) {
    this.a = a;
    this.b = b;
  }
  u.Object.defineProperties(Ka.prototype, {
    event: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.a;
      },
    },
    origin: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.b;
      },
    },
  });
  function N(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c] = arguments[c];
    La(
      function () {
        throw new (Function.prototype.bind.apply(
          Error,
          [null, "Could not complete the test successfully - "].concat(q(b))
        ))();
      },
      function () {
        return console.error.apply(console, q(b));
      }
    );
  }
  function Ma(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c] = arguments[c];
    La(
      function () {},
      function () {
        return console.error.apply(console, q(b));
      }
    );
  }
  function La(a, b) {
    "undefined" !== typeof jasmine && jasmine
      ? a()
      : "undefined" !== typeof console && console && console.error && b();
  }
  function Na() {
    this.f = [];
    this.b = [];
    this.c = [];
    this.g = [];
    this.h = {};
    this.a = L();
  }
  function Oa(a) {
    a.f = [];
    a.b = [];
    a.c = [];
    a.g = [];
  }
  function Pa(a, b) {
    if (void 0 !== a.a && a.a.v && !1 !== Qa(a, b)) {
      var c = b.event;
      a.c
        .filter(function (d) {
          return d.type === c.type;
        })
        .forEach(function (d) {
          return P(a, d, c);
        });
    }
  }
  function Ra(a, b) {
    a.f.push(b);
    Pa(a, b);
  }
  function Sa(a, b, c) {
    void 0 !== a.a &&
      a.a.v &&
      a.f
        .filter(function (d) {
          return d.event.type === b && Qa(a, d);
        })
        .map(function (d) {
          return d.event;
        })
        .forEach(function (d) {
          P(a, c, d);
        });
  }
  function Qa(a, b) {
    var c = b.event.type,
      d = -1 !== Object.values(A).indexOf(c) && "volumeChange" !== c;
    return "impression" === c || ("loaded" === c && a.a.b)
      ? b.origin === L().i
      : d
      ? b.origin === L().j
      : !0;
  }
  function Ta(a, b, c, d) {
    "media" === b || "video" === b
      ? Ua(a, c, d)
      : ((c = { type: b, P: d, R: c }), a.c.push(c), Sa(a, b, c));
  }
  function Ua(a, b, c) {
    Object.keys(A).forEach(function (d) {
      d = A[d];
      var e = { type: d, P: c, R: b };
      a.c.push(e);
      Sa(a, d, e);
    });
  }
  function Va(a, b, c, d) {
    var e = { W: c, P: d, R: b };
    a.g.push(e);
    a.b.forEach(function (f) {
      var l = Wa(f);
      "sessionStart" === f.event.type && Xa(a, l, e);
      P(a, e, l);
    });
  }
  function Ya(a, b, c) {
    var d = Q(a, "sessionError", "native", { errorType: b, message: c });
    a.b.push(d);
    a.g.forEach(function (e) {
      P(a, e, d.event);
    });
  }
  function Za(a, b) {
    a.h = Object.assign(a.h, b);
    b = a.a.c;
    if (void 0 !== b) {
      b = Object.assign({}, $a(a, ab(a, bb(a, { context: b }), !0)), {
        supportsLoadedEvent: !!a.a.b || "video" == a.a.a,
      });
      Object.assign(b, { pageUrl: Ja(), contentUrl: a.a.m });
      var c = Q(a, "sessionStart", "native", b);
      a.b.push(c);
      a.g.forEach(function (d) {
        var e = Wa(c);
        Xa(a, e, d);
        P(a, d, e);
      }, a);
      cb(a);
    }
  }
  function Xa(a, b, c) {
    c.W && (b.data.verificationParameters = a.h[c.W]);
    c.P &&
      (c = a.a.u.get(c.P)) &&
      ((b.data.verificationParameters = c.verificationParameters),
      (b.data.context.accessMode = c.accessMode),
      "full" === c.accessMode &&
        (a.a.g && (b.data.context.videoElement = a.a.g),
        a.a.f && (b.data.context.slotElement = a.a.f)));
  }
  function db(a) {
    var b = a.g,
      c = Q(a, "sessionFinish", "native");
    a.b.push(c);
    var d = a.a.c;
    (d = !d || "native" !== d.adSessionType) && Oa(a);
    b.forEach(function (e) {
      return P(a, e, c.event);
    });
    d && ((a.h = {}), Ha(), Ha());
  }
  function P(a, b, c) {
    var d = b.R;
    (b = b.P) && !a.a.u.has(b)
      ? N(
          "Listener/observer not called, probably because it was added after its intended ad session had already finished."
        )
      : a.i(d, c);
  }
  Na.prototype.i = function (a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    try {
      a.apply(null, q(c));
    } catch (e) {
      Ma(e);
    }
  };
  function cb(a) {
    var b = a.f
        .filter(function (f) {
          return (Object.values(A).includes(f.event.type) &&
            "video" == a.a.a &&
            f.origin === a.a.j) ||
            ("loaded" == f.event.type &&
              "display" == a.a.a &&
              f.origin === a.a.i)
            ? !0
            : !1;
        })
        .map(function (f) {
          return f.event;
        }),
      c = a.a.v || "",
      d = {};
    b = p(b);
    for (var e = b.next(); !e.done; d = { A: d.A }, e = b.next()) {
      d.A = e.value;
      d.A.adSessionId || (d.A.adSessionId = c);
      if ("loaded" == d.A.type) {
        if (!a.a.b && "display" == a.a.a) continue;
        d.A.data = ab(a, bb(a, d.A.data));
      }
      a.c
        .filter(
          (function (f) {
            return function (l) {
              return l.type === f.A.type;
            };
          })(d)
        )
        .forEach(
          (function (f) {
            return function (l) {
              return l.R(f.A);
            };
          })(d)
        );
    }
  }
  function eb(a, b) {
    a: {
      b = new Set(b);
      a = p(a.f.concat(a.b));
      for (var c = a.next(); !c.done; c = a.next())
        if (((c = c.value), b.has(c.event.type) && "javascript" != c.origin)) {
          b = !0;
          break a;
        }
      b = !1;
    }
    return b
      ? (N(
          "Event owner cannot be registered after its events have already been published."
        ),
        !1)
      : !0;
  }
  function fb(a) {
    var b = a.a.i;
    return "none" != b && "javascript" != b
      ? (N("Impression event is owned by " + (a.a.i + ", not javascript.")), !1)
      : !0;
  }
  function gb(a) {
    var b = a.a.j;
    return "none" != b && "javascript" != b
      ? (N("Media events are owned by " + (a.a.j + ", not javascript.")), !1)
      : !0;
  }
  function ab(a, b, c) {
    c = void 0 === c ? !1 : c;
    b = Object.assign({}, b);
    a.a.a && Object.assign(b, { mediaType: a.a.a });
    a.a.b &&
      (c || "definedByJavaScript" !== a.a.b) &&
      Object.assign(b, { creativeType: a.a.b });
    return b;
  }
  function $a(a, b) {
    return a.a.H ? Object.assign(b, { lastActivity: a.a.H }) : b;
  }
  function bb(a, b) {
    return a.a.s ? Object.assign({}, b, { impressionType: a.a.s }) : b;
  }
  function Q(a, b, c, d) {
    return new Ka(
      {
        adSessionId: a.a.v || "",
        timestamp: new Date().getTime(),
        type: b,
        data: d,
      },
      c
    );
  }
  function Wa(a) {
    a = a.event;
    var b = a.data ? Object.assign({}, a.data) : void 0;
    "sessionStart" === a.type && (b.context = Object.assign({}, b.context));
    return {
      adSessionId: a.adSessionId,
      timestamp: a.timestamp,
      type: a.type,
      data: b,
    };
  }
  function hb(a) {
    return !(!a || !a.tagName || "iframe" !== a.tagName.toLowerCase());
  }
  function R(a, b, c) {
    this.f = a;
    this.U = b;
    this.M = c;
    this.c = L();
    this.b = null;
    this.a = this.g = this.F = void 0;
    this.S = !0;
    this.l = void 0;
    ib(this);
  }
  function ib(a) {
    if (!a.b) {
      var b;
      a: {
        if (
          (b = a.f.document) &&
          b.getElementsByClassName &&
          (b = b.getElementsByClassName("omid-element"))
        ) {
          if (1 == b.length) {
            b = b[0];
            break a;
          }
          1 < b.length &&
            a.S &&
            (Ya(
              a.M,
              "generic",
              "More than one element with 'omid-element' class name."
            ),
            (a.S = !1));
        }
        b = null;
      }
      if (b && b.tagName && "video" === b.tagName.toLowerCase()) a.c.g = b;
      else if (b && b.tagName) a.c.f = b;
      else return;
      jb(a);
    }
  }
  function jb(a) {
    a.c.g
      ? ((a.b = a.c.g), a.i())
      : a.c.f && ((a.b = a.c.f), hb(a.b) ? a.c.h && a.i() : a.i());
  }
  function kb(a) {
    a.a && (hb(a.b) ? a.c.h && (a.I(), lb(a)) : (a.I(), lb(a)));
  }
  R.prototype.s = function () {
    this.l &&
      (this.f.document.removeEventListener("visibilitychange", this.l),
      (this.l = void 0));
  };
  R.prototype.i = function () {
    var a = this;
    this.l ||
      ((this.l = function () {
        a.c.l = a.f.document.hidden ? "backgrounded" : "foregrounded";
        kb(a);
      }),
      this.f.document.addEventListener("visibilitychange", this.l));
  };
  function lb(a) {
    if (a.F) {
      a.c.M = a.F;
      a = a.U;
      var b = a.a.M,
        c = a.a.F;
      if (b && !b.O(c)) {
        c = wa(b);
        var d = a.b;
        "audio" != d.a.b && Ra(d, Q(d, "geometryChange", "native", c));
        a.a.F = b;
      }
    }
  }
  function mb(a) {
    if (a.a && a.c.h) {
      var b = new B(a.c.h, !1),
        c = a.a.x;
      a = a.a.y;
      b.x += c;
      b.y += a;
      b.B += c;
      b.C += a;
      b.K = !0;
      return b;
    }
  }
  function nb(a, b, c) {
    return ob(a, "setInterval")(b, c);
  }
  function pb(a, b) {
    ob(a, "clearInterval")(b);
  }
  function qb(a, b) {
    ob(a, "clearTimeout")(b);
  }
  function ob(a, b) {
    return a.a && a.a[b] ? a.a[b] : rb(a, b);
  }
  function sb(a, b, c, d) {
    if (a.a.document && a.a.document.body) {
      var e = a.a.document.createElement("img");
      e.width = 1;
      e.height = 1;
      e.style.display = "none";
      e.src = b;
      c &&
        e.addEventListener("load", function () {
          return c();
        });
      d &&
        e.addEventListener("error", function () {
          return d();
        });
      a.a.document.body.appendChild(e);
    } else rb(a, "sendUrl")(b, c, d);
  }
  function rb(a, b) {
    if (a.a && a.a.omidNative && a.a.omidNative[b])
      return a.a.omidNative[b].bind(a.a.omidNative);
    throw Error('Native interface method "' + b + '" not found.');
  }
  function S(a, b, c, d, e) {
    R.call(this, a, c, e);
    this.m = b;
    this.h = void 0;
    this.j = d;
  }
  r(S, R);
  S.prototype.s = function () {
    void 0 !== this.h && (pb(this.j, this.h), (this.h = void 0));
    R.prototype.s.call(this);
  };
  S.prototype.i = function () {
    var a = this;
    R.prototype.i.call(this);
    null == this.b
      ? (this.h = void 0)
      : void 0 === this.h &&
        ((this.h = nb(
          this.j,
          function () {
            return tb(a);
          },
          200
        )),
        tb(this));
  };
  S.prototype.I = function () {
    if (this.g) {
      var a = mb(this);
      if (a) {
        this.a.L = !1;
        a.L = !0;
        for (var b = !1, c = 0; c < this.a.J.length; c++)
          if (this.a.J[c].L) {
            this.a.J[c] = a;
            b = !0;
            break;
          }
        b || this.a.J.push(a);
      } else this.a.L = !0;
      b = this.m;
      c = this.c.l;
      var d = this.c.v,
        e = this.H();
      a = new va();
      var f = new B(this.g, !1);
      xa(a, f);
      Da(b, f, a, d);
      if (e)
        if (
          (f.V && (J(a, "backgrounded"), J(a, "noOutputDevice")),
          "backgrounded" === c)
        )
          J(a, "backgrounded");
        else if (void 0 !== a.a) {
          for (b = 0; b < a.h.length; b++) Ca(a, a.h[b]) && a.s.push(a.h[b]);
          for (b = 0; b < a.j.length; b++) {
            if ((c = Ca(a, a.j[b]))) {
              b: {
                c = a.j[b];
                for (d = 0; d < a.f.length; d++)
                  if (a.f[d].O(c)) {
                    c = !0;
                    break b;
                  }
                c = !1;
              }
              c = !c;
            }
            c && (J(a, "obstructed"), a.f.push(a.j[b]));
          }
          Ba(a);
        } else J(a, "notFound");
      else
        (a.g = ["unmeasurable"]),
          (a.i = void 0),
          (a.l = 0),
          (a.f = []),
          a.a &&
            ((b = a.a),
            (c = {}),
            (b = new B(
              ((c.x = 0),
              (c.y = 0),
              (c.width = b.width),
              (c.height = b.height),
              c),
              b.a
            )),
            (a.a = b)),
          (a.b = ya());
      this.F = a;
    }
  };
  S.prototype.H = function () {
    return ub(this);
  };
  function tb(a) {
    if (void 0 !== a.h) {
      if (ub(a)) {
        var b = a.f.top;
        b = new B(new Ea(b.innerWidth, b.innerHeight), !1);
      } else b = new B(new Ea(0, 0), !1);
      var c = a.b.getBoundingClientRect();
      if (null == c.x || isNaN(c.x)) c.x = c.left;
      if (null == c.y || isNaN(c.y)) c.y = c.top;
      c = new B(c, !1);
      (b.O(a.g) && c.O(a.a)) ||
        ((a.a = c), (a.a.K = !0), (a.g = b), a.g.J.push(a.a), kb(a));
    }
  }
  function ub(a) {
    try {
      var b = a.f.top;
      return 0 <= b.innerHeight && 0 <= b.innerWidth;
    } catch (c) {}
    return !1;
  }
  function U(a, b, c, d) {
    R.call(this, a, c, d);
    this.u = this.j = this.m = this.h = void 0;
    this.N = !1;
    this.G = void 0;
  }
  r(U, R);
  U.prototype.s = function () {
    this.h && this.h.disconnect();
    vb(this);
    R.prototype.s.call(this);
  };
  U.prototype.i = function () {
    R.prototype.i.call(this);
    this.b && (this.h || (this.h = wb(this)), xb(this), yb(this.b) && zb(this));
  };
  U.prototype.I = function () {
    if (this.a && this.G) {
      var a = mb(this);
      if (a) {
        var b = a;
        var c = this.G;
        var d = Math.max(a.x, c.x);
        var e = Math.max(a.y, c.y),
          f = Math.min(a.B, c.B);
        a = Math.min(a.C, c.C);
        f <= d || a <= e
          ? (d = null)
          : ((c = {}),
            (d = new B(
              ((c.x = d),
              (c.y = e),
              (c.width = Math.abs(f - d)),
              (c.height = Math.abs(a - e)),
              c),
              !1
            )));
        d || (d = new B({ x: 0, y: 0, width: 0, height: 0 }, !1));
      } else (b = this.a), (d = this.G);
      e = new va();
      this.g && xa(e, this.g);
      (f = "backgrounded" == this.c.l) && J(e, "backgrounded");
      e.a = b;
      e.b = d;
      Ba(e);
      this.N
        ? !f && I(e.a)
          ? J(e, "hidden")
          : f || 100 === e.l || J(e, "clipped")
        : J(e, "viewport");
      this.F = e;
    }
  };
  U.prototype.H = function () {
    return !0;
  };
  function vb(a) {
    a.m && (a.m.disconnect(), (a.m = void 0));
    a.j && (a.j.disconnect(), (a.j = void 0));
    a.u && ((0, a.f.removeEventListener)("resize", a.u), (a.u = void 0));
  }
  function xb(a) {
    a.h && a.b && (a.h.unobserve(a.b), a.h.observe(a.b));
  }
  function yb(a) {
    a = a.getBoundingClientRect();
    return 0 == a.width || 0 == a.height;
  }
  function wb(a) {
    return new a.f.IntersectionObserver(
      function (b) {
        try {
          if (b.length) {
            for (var c, d = b[0], e = 1; e < b.length; e++)
              b[e].time > d.time && (d = b[e]);
            c = d;
            a.g = Ab(c.rootBounds);
            a.a = Ab(c.boundingClientRect);
            a.G = Ab(c.intersectionRect);
            a.N = !!c.isIntersecting;
            kb(a);
          }
        } catch (f) {
          a.s(),
            Ya(
              a.M,
              "generic",
              "Problem handling IntersectionObserver callback: " + f.message
            );
        }
      },
      {
        root: null,
        rootMargin: "0px",
        threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1],
      }
    );
  }
  function zb(a) {
    a.f.ResizeObserver
      ? a.m ||
        ((a.m = Bb(a, function () {
          return Cb(a);
        })),
        a.m.observe(a.b))
      : (a.u ||
          ((a.u = function () {
            return Cb(a);
          }),
          (0, a.f.addEventListener)("resize", a.u)),
        a.j ||
          ((a.j = new MutationObserver(function () {
            return Cb(a);
          })),
          a.j.observe(a.b, { childList: !1, attributes: !0, subtree: !1 })));
  }
  function Cb(a) {
    a.b && !yb(a.b) && (xb(a), vb(a));
  }
  function Bb(a, b) {
    return new a.f.ResizeObserver(b);
  }
  function Ab(a) {
    if (
      a &&
      null !== a.x &&
      null !== a.y &&
      null !== a.width &&
      null !== a.height
    )
      return new B(a, !1);
  }
  function V(a, b, c, d) {
    this.b = a;
    this.method = b;
    this.version = c;
    this.a = d;
  }
  function Db(a) {
    return (
      !!a &&
      void 0 !== a.omid_message_guid &&
      void 0 !== a.omid_message_method &&
      void 0 !== a.omid_message_version &&
      "string" === typeof a.omid_message_guid &&
      "string" === typeof a.omid_message_method &&
      "string" === typeof a.omid_message_version &&
      (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
    );
  }
  function Eb(a) {
    return new V(
      a.omid_message_guid,
      a.omid_message_method,
      a.omid_message_version,
      a.omid_message_args
    );
  }
  function Gb(a) {
    var b = {};
    b =
      ((b.omid_message_guid = a.b),
      (b.omid_message_method = a.method),
      (b.omid_message_version = a.version),
      b);
    void 0 !== a.a && (b.omid_message_args = a.a);
    return b;
  }
  function Hb(a) {
    this.c = a;
  }
  function W(a) {
    this.c = a;
    this.handleExportedMessage = W.prototype.f.bind(this);
  }
  r(W, Hb);
  W.prototype.b = function (a, b) {
    b = void 0 === b ? this.c : b;
    if (!b)
      throw Error(
        "Message destination must be defined at construction time or when sending the message."
      );
    b.handleExportedMessage(Gb(a), this);
  };
  W.prototype.f = function (a, b) {
    Db(a) && this.a && this.a(Eb(a), b);
  };
  function Ib(a) {
    return Jb(a, "SessionService.");
  }
  function Jb(a, b) {
    return (a = a.match(new RegExp("^" + b + "(.*)"))) && a[1];
  }
  function Kb(a) {
    this.b = a;
  }
  Kb.prototype.a = function (a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    return this.b("SessionService." + a, this.c.bind(this, a, c), c);
  };
  Kb.prototype.c = function (a, b, c) {
    switch (a) {
      case "registerSessionObserver":
        (a = p(b).next().value), a(c);
    }
  };
  function X(a, b) {
    return a.a.bind(a, b);
  }
  function Lb(a) {
    var b = void 0 === b ? M : b;
    null == b.omidSessionInterface &&
      ((a = {
        setClientInfo: X(a, "setClientInfo"),
        registerSessionObserver: X(a, "registerSessionObserver"),
        startAdSession: X(a, "startSession"),
        finishAdSession: X(a, "finishSession"),
        reportError: X(a, "sessionError"),
        registerAdEvents: X(a, "registerAdEvents"),
        registerMediaEvents: X(a, "registerMediaEvents"),
        injectVerificationScriptResources: X(
          a,
          "injectVerificationScriptResources"
        ),
        setSlotElement: X(a, "setSlotElement"),
        setVideoElement: X(a, "setVideoElement"),
        setElementBounds: X(a, "setElementBounds"),
        setCreativeType: X(a, "setCreativeType"),
        setImpressionType: X(a, "setImpressionType"),
        setContentUrl: X(a, "setContentUrl"),
        adEvents: {
          impressionOccurred: X(a, "impressionOccurred"),
          loaded: X(a, "loaded"),
        },
        mediaEvents: {
          start: X(a, "start"),
          firstQuartile: X(a, "firstQuartile"),
          midpoint: X(a, "midpoint"),
          thirdQuartile: X(a, "thirdQuartile"),
          complete: X(a, "complete"),
          pause: X(a, "pause"),
          resume: X(a, "resume"),
          bufferStart: X(a, "bufferStart"),
          bufferFinish: X(a, "bufferFinish"),
          skipped: X(a, "skipped"),
          volumeChange: X(a, "volumeChange"),
          playerStateChange: X(a, "playerStateChange"),
          adUserInteraction: X(a, "adUserInteraction"),
        },
      }),
      (a.mediaEvents.loaded = a.adEvents.loaded),
      (a.videoEvents = a.mediaEvents),
      Object.freeze(a),
      Object.defineProperty(b, "omidSessionInterface", {
        value: a,
        writable: !1,
      }));
  }
  function Mb(a, b) {
    this.c = b = void 0 === b ? M : b;
    var c = this;
    a.addEventListener("message", function (d) {
      if ("object" === typeof d.data) {
        var e = d.data;
        Db(e) && d.source && c.a && c.a(Eb(e), d.source);
      }
    });
  }
  r(Mb, Hb);
  Mb.prototype.b = function (a, b) {
    b = void 0 === b ? this.c : b;
    if (!b)
      throw Error(
        "Message destination must be defined at construction time or when sending the message."
      );
    b.postMessage(Gb(a), "*");
  };
  function Nb() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (a) {
        var b = (16 * Math.random()) | 0;
        return "y" === a ? ((b & 3) | 8).toString(16) : b.toString(16);
      }
    );
  }
  function Ob(a) {
    if (!a.a || !a.a.document)
      throw Error("OMID Service Script is not running within a window.");
    var b = a.b;
    a.b = [];
    b.forEach(function (c) {
      try {
        var d = a.c.G ? "limited" : "full",
          e = c.accessMode,
          f =
            "string" === typeof e && -1 !== Object.values(pa).indexOf(e)
              ? c.accessMode
              : null;
        var l = f ? f : d;
        c.accessMode = l;
        a: {
          var g = c.resourceUrl,
            h = a.a.location.origin;
          try {
            var k = new URL(g, h);
            break a;
          } catch (O) {}
          try {
            k = new URL(g);
            break a;
          } catch (O) {}
          k = null;
        }
        if ((d = k)) {
          var m = Nb(),
            t = a.a.document,
            w = t.createElement("iframe");
          w.id = "omid-verification-script-frame-" + m;
          w.style.display = "none";
          ["full", "limited"].includes(l)
            ? (w.srcdoc =
                "<html><head>\n<script type=\"text/javascript\">window['omidVerificationProperties'] = {\n'serviceWindow': window.parent,\n'injectionSource': 'web',\n'injectionId': '" +
                (m +
                  '\',\n};\x3c/script>\n<script type="text/javascript" src="') +
                d.href +
                '">\x3c/script>\n</head><body></body></html>')
            : "domain" == l && (w.src = Pb(a, m, d).href);
          ["domain", "limited"].includes(l) && (w.sandbox = "allow-scripts");
          t.body.appendChild(w);
          var G = c.vendorKey,
            H = c.verificationParameters;
          G = void 0 === G ? "" : G;
          H = void 0 === H ? "" : H;
          G &&
            "string" === typeof G &&
            "" !== G &&
            H &&
            "string" === typeof H &&
            "" !== H &&
            (a.f.h[G] = H);
          a.c.u.set(m, c);
        }
      } catch (O) {
        Ma(
          "OMID verification script " + c.resourceUrl + " failed to load: " + O
        );
      }
    });
  }
  function Pb(a, b, c) {
    var d = "/.well-known/omid/omloader-v1.html#";
    new Map([
      ["verificationScriptUrl", c.href],
      ["injectionId", b],
    ]).forEach(function (e, f) {
      d += encodeURIComponent(f) + "=" + encodeURIComponent(e) + "&";
    });
    b = null;
    try {
      b = new URL(d, a.a.parent.location.origin);
    } catch (e) {
      throw Error("OMID Service Script cannot access the parent window.");
    }
    return b;
  }
  function Qb() {
    var a = Rb,
      b = Sb,
      c = this;
    this.c = Y;
    this.b = a;
    this.a = L();
    this.g = b;
    this.f = !1;
    this.registerSessionObserver(function (d) {
      return Tb(c, d);
    });
  }
  n = Qb.prototype;
  n.registerSessionObserver = function (a) {
    Va(this.c, a);
  };
  n.setSlotElement = function (a) {
    a && a.tagName
      ? ((this.a.f = a), this.b && jb(this.b))
      : N("setSlotElement called with a non-HTMLElement.  It will be ignored.");
  };
  n.setElementBounds = function (a) {
    this.a.h = a;
    this.b && jb(this.b);
    this.b && kb(this.b);
  };
  n.error = function (a, b) {
    Ya(this.c, a, b);
  };
  n.registerAdEvents = function () {
    var a = this.c;
    eb(a, ["impression"]) && fb(a) && (a.a.i = "javascript");
  };
  n.registerMediaEvents = function () {
    var a = this.c;
    eb(a, Object.values(A)) && gb(a) && (a.a.j = "javascript");
  };
  function Z(a, b, c) {
    if ("impression" == b)
      fb(a.c) &&
        ((b = a.c),
        (c = (c = L().F) ? wa(c) : void 0),
        (c = ab(b, bb(b, c))),
        Ra(b, Q(b, "impression", "javascript", c)),
        a.b && ib(a.b));
    else {
      if ("loaded" == b) {
        var d = c;
        d = void 0 === d ? null : d;
        gb(a.c) &&
          ((c = a.c), c.a.b || "display" != c.a.a) &&
          ((d = Q(
            c,
            "loaded",
            "javascript",
            ab(c, bb(c, void 0 === d ? null : d))
          )),
          Ra(c, d));
      } else if (gb(a.c)) {
        d = a.c;
        ("start" !== b && "volumeChange" !== b) ||
          null != (c && c.deviceVolume) ||
          (c.deviceVolume = d.a.N);
        if (c && ("start" === b || "volumeChange" === b)) {
          var e = c.videoPlayerVolume,
            f = c.mediaPlayerVolume;
          null != e
            ? (Object.assign(c, { mediaPlayerVolume: e }), (d.a.I = e))
            : null != f &&
              (Object.assign(c, { videoPlayerVolume: f }), (d.a.I = f));
        }
        Ra(d, Q(d, b, "javascript", c));
      }
      ["loaded", "start"].includes(b) && a.b && ib(a.b);
    }
  }
  n.injectVerificationScriptResources = function (a) {
    var b = this.g;
    b.b.push.apply(b.b, q(a));
    if (this.f)
      try {
        Ob(this.g);
      } catch (c) {
        N(c.message);
      }
  };
  n.setCreativeType = function (a, b) {
    b = void 0 === b ? null : b;
    if (!this.a.a || this.a.b)
      (this.a.b = a),
        "video" == a || "audio" == a
          ? (this.a.a = "video")
          : "htmlDisplay" == a || "nativeDisplay" == a
          ? (this.a.a = "display")
          : "definedByJavaScript" == a &&
            b &&
            (this.a.a = "none" == b ? "display" : "video");
  };
  n.setImpressionType = function (a) {
    if (!this.a.a || this.a.b) this.a.s = a;
  };
  function Tb(a, b) {
    if ("sessionStart" === b.type) {
      a.f = !0;
      try {
        Ob(a.g);
      } catch (c) {
        N(c.message);
      }
    }
    "sessionFinish" === b.type &&
      ((a.f = !1),
      ((b = L().c) && "native" == b.adSessionType) ||
        a.registerSessionObserver(function (c) {
          return Tb(a, c);
        }));
  }
  n.setClientInfo = function (a, b, c) {
    var d = this.a.c || {};
    d.omidJsInfo = Object.assign({}, d.omidJsInfo, {
      sessionClientVersion: a,
      partnerName: b,
      partnerVersion: c,
    });
    this.a.c = d;
    return this.a.c.omidJsInfo.serviceVersion;
  };
  function Ub(a) {
    return /\d+\.\d+\.\d+(-.*)?/.test(a);
  }
  function Vb(a) {
    a = a.split("-")[0].split(".");
    for (var b = ["1", "0", "3"], c = 0; 3 > c; c++) {
      var d = parseInt(a[c], 10),
        e = parseInt(b[c], 10);
      if (d > e) break;
      else if (d < e) return !1;
    }
    return !0;
  }
  function Wb(a, b) {
    return Ub(a) && Vb(a)
      ? b
        ? b
        : []
      : b && "string" === typeof b
      ? JSON.parse(b)
      : [];
  }
  var Xb = new (function () {})();
  function Yb() {
    var a = Zb,
      b = this;
    var c = void 0 === c ? omidGlobal : c;
    this.a = a;
    this.g = c;
    this.b = new W();
    this.g.omid = this.g.omid || {};
    this.g.omid.v1_SessionServiceCommunication = this.b;
    this.f = c && c.addEventListener && c.postMessage ? new Mb(c) : null;
    this.c = null;
    this.b.a = this.h.bind(this);
    this.f && (this.f.a = this.i.bind(this));
    this.j = new Kb(function (d, e, f) {
      try {
        $b(b, d, e, f);
      } catch (l) {
        N(ac(l));
      }
    });
    Lb(this.j);
  }
  Yb.prototype.h = function (a, b) {
    null != Ib(a.method) && bc(this, Xb) && cc(this, a, b, this.b);
  };
  Yb.prototype.i = function (a, b) {
    null != Ib(a.method) && bc(this, b) && cc(this, a, b, this.f);
  };
  function bc(a, b) {
    a.c || (a.c = b);
    return a.c != b
      ? (N(
          "The source of session client messages cannot be changed from the source of the first message."
        ),
        !1)
      : !0;
  }
  function cc(a, b, c, d) {
    function e(h) {
      for (var k = [], m = 0; m < arguments.length; ++m) k[m] = arguments[m];
      k = new V(f, "response", g, Ub(g) && Vb(g) ? k : JSON.stringify(k));
      d.b(k, c);
    }
    var f = b.b,
      l = b.method,
      g = b.version;
    b = Wb(g, b.a);
    try {
      $b(a, l, e, b);
    } catch (h) {
      d.b(new V(f, "error", g, ac(h)), c);
    }
  }
  function $b(a, b, c, d) {
    if (null != Ib(b))
      switch (Ib(b)) {
        case "registerAdEvents":
          a.a.registerAdEvents();
          break;
        case "registerMediaEvents":
          a.a.registerMediaEvents();
          break;
        case "registerSessionObserver":
          a.a.registerSessionObserver(c);
          break;
        case "setSlotElement":
          var e = p(d).next().value;
          a.a.setSlotElement(e);
          break;
        case "setVideoElement":
          e = p(d).next().value;
          a = a.a;
          e && e.tagName && "video" === e.tagName.toLowerCase()
            ? ((a.a.g = e), a.b && jb(a.b))
            : N(
                "setVideoElement called with a non-HTMLVideoElement. It will be ignored."
              );
          break;
        case "setElementBounds":
          e = p(d).next().value;
          a.a.setElementBounds(e);
          break;
        case "startSession":
          c = p(d).next().value;
          null != c && "object" === typeof c
            ? ((b = c.customReferenceData),
              (c = c.underEvaluation),
              "string" === typeof b || (b = void 0),
              "boolean" === typeof c || (c = !1),
              (c = { customReferenceData: b, underEvaluation: c }))
            : (c = null);
          if (null == c) break;
          a = a.a;
          b = c;
          var f;
          e = void 0 === e ? null : e;
          null == f && (f = Nb());
          b.canMeasureVisibility = a.b.H();
          a.a.v = f;
          c = a.a;
          b = f = b;
          void 0 !== b.contentUrl &&
            ((c.m = b.contentUrl), (b.contentUrl = void 0));
          b = c.c || {};
          f.omidJsInfo = Object.assign(
            {},
            b.omidJsInfo || {},
            f.omidJsInfo || {}
          );
          b = f = Object.assign({}, b, f);
          c.G ||
            (null != c.g
              ? ((b.videoElement = c.g), (b.accessMode = "full"))
              : null != c.f &&
                ((b.slotElement = c.f), (b.accessMode = "full")));
          c.c = f;
          Za(a.c, e);
          a.b && ib(a.b);
          break;
        case "finishSession":
          a = a.a;
          db(a.c);
          a.b.s();
          break;
        case "impressionOccurred":
          Z(a.a, "impression");
          break;
        case "loaded":
          (e = p(d).next().value)
            ? ((c = {
                skippable: e.isSkippable,
                autoPlay: e.isAutoPlay,
                position: e.position,
              }),
              e.isSkippable && (c.skipOffset = e.skipOffset),
              Z(a.a, "loaded", c))
            : Z(a.a, "loaded");
          break;
        case "start":
          c = p(d);
          e = c.next().value;
          c = c.next().value;
          Z(a.a, "start", { duration: e, mediaPlayerVolume: c });
          break;
        case "firstQuartile":
          Z(a.a, "firstQuartile");
          break;
        case "midpoint":
          Z(a.a, "midpoint");
          break;
        case "thirdQuartile":
          Z(a.a, "thirdQuartile");
          break;
        case "complete":
          Z(a.a, "complete");
          break;
        case "pause":
          Z(a.a, "pause");
          break;
        case "resume":
          Z(a.a, "resume");
          break;
        case "bufferStart":
          Z(a.a, "bufferStart");
          break;
        case "bufferFinish":
          Z(a.a, "bufferFinish");
          break;
        case "skipped":
          Z(a.a, "skipped");
          break;
        case "volumeChange":
          e = { mediaPlayerVolume: p(d).next().value };
          Z(a.a, "volumeChange", e);
          break;
        case "playerStateChange":
          e = { state: p(d).next().value };
          Z(a.a, "playerStateChange", e);
          break;
        case "adUserInteraction":
          e = { interactionType: p(d).next().value };
          Z(a.a, "adUserInteraction", e);
          break;
        case "setClientInfo":
          b = p(d);
          e = b.next().value;
          f = b.next().value;
          b = b.next().value;
          a = a.a.setClientInfo(e, f, b);
          c(a);
          break;
        case "injectVerificationScriptResources":
          e = p(d).next().value;
          a.a.injectVerificationScriptResources(e);
          break;
        case "setCreativeType":
          e = p(d).next().value;
          a.a.setCreativeType(e);
          break;
        case "setImpressionType":
          e = p(d).next().value;
          a.a.setImpressionType(e);
          break;
        case "setContentUrl":
          e = p(d).next().value;
          a.a.a.m = e;
          break;
        case "sessionError":
          (c = p(d)),
            (e = c.next().value),
            (c = c.next().value),
            a.a.error(e, c);
      }
  }
  function ac(a) {
    return (
      "\n        name: " +
      a.name +
      "\n        message: " +
      a.message +
      "\n        filename: " +
      a.filename +
      "\n        lineNumber: " +
      a.lineNumber +
      "\n        columnNumber: " +
      a.columnNumber +
      "\n        stack: " +
      a.stack +
      "\n        toString(): " +
      a.toString()
    );
  }
  function dc() {
    var a = Y,
      b = ec;
    var c = void 0 === c ? M : c;
    this.g = a;
    this.a = b;
    this.h = {};
    this.f = {};
    this.c = new W();
    c.omid = c.omid || {};
    c.omid.v1_VerificationServiceCommunication = this.c;
    this.b = null;
    c && c.addEventListener && c.postMessage && (this.b = new Mb(c));
    this.c.a = this.i.bind(this);
    this.b && (this.b.a = this.j.bind(this));
  }
  function fc(a, b, c, d) {
    sb(a.a, b, c, d);
  }
  function gc(a, b, c, d) {
    rb(a.a, "downloadJavaScriptResource")(b, c, d);
  }
  dc.prototype.j = function (a, b) {
    this.b && hc(this, a, b, this.b);
  };
  dc.prototype.i = function (a, b) {
    hc(this, a, b, this.c);
  };
  function hc(a, b, c, d) {
    function e(D) {
      for (var T = [], ma = 0; ma < arguments.length; ++ma)
        T[ma] = arguments[ma];
      T = new V(f, "response", g, Ub(g) && Vb(g) ? T : JSON.stringify(T));
      d.b(T, c);
    }
    var f = b.b,
      l = b.method,
      g = b.version;
    b = Wb(g, b.a);
    if (null != Jb(l, "VerificationService.")) {
      l = Jb(l, "VerificationService.");
      try {
        switch (l) {
          case "addEventListener":
            var h = p(b),
              k = h.next().value,
              m = h.next().value;
            Ta(a.g, k, e, m);
            break;
          case "addSessionListener":
            var t = p(b),
              w = t.next().value,
              G = t.next().value;
            Va(a.g, e, w, G);
            break;
          case "sendUrl":
            var H = p(b).next().value;
            fc(
              a,
              H,
              function () {
                return e(!0);
              },
              function () {
                return e(!1);
              }
            );
            break;
          case "setTimeout":
            var O = p(b),
              mc = O.next().value,
              nc = O.next().value;
            a.h[mc] = ob(a.a, "setTimeout")(e, nc);
            break;
          case "clearTimeout":
            var oc = p(b).next().value;
            qb(a.a, a.h[oc]);
            break;
          case "setInterval":
            var Fb = p(b),
              pc = Fb.next().value,
              qc = Fb.next().value;
            a.f[pc] = nb(a.a, e, qc);
            break;
          case "clearInterval":
            var rc = p(b).next().value;
            pb(a.a, a.f[rc]);
            break;
          case "injectJavaScriptResource":
            var sc = p(b).next().value;
            gc(
              a,
              sc,
              function (D) {
                return e(!0, D);
              },
              function () {
                return e(!1);
              }
            );
            break;
          case "getVersion":
            p(b).next();
            var tc = L().c.omidJsInfo;
            e(tc.serviceVersion);
        }
      } catch (D) {
        d.b(
          new V(
            f,
            "error",
            g,
            "\n              name: " +
              D.name +
              "\n              message: " +
              D.message +
              "\n              filename: " +
              D.filename +
              "\n              lineNumber: " +
              D.lineNumber +
              "\n              columnNumber: " +
              D.columnNumber +
              "\n              stack: " +
              D.stack +
              "\n              toString(): " +
              D.toString() +
              "\n          "
          ),
          c
        );
      }
    }
  }
  function ic() {
    var a = M.document.createElement("iframe");
    a.id = "omid_v1_present";
    a.name = "omid_v1_present";
    a.style.display = "none";
    M.document.body.appendChild(a);
  }
  function jc() {
    var a = new MutationObserver(function (b) {
      b.forEach(function (c) {
        "BODY" === c.addedNodes[0].nodeName && (ic(), a.disconnect());
      });
    });
    a.observe(M.document.documentElement, { childList: !0 });
  }
  var Y = new Na(),
    ec = new (function () {
      var a;
      this.a = a = void 0 === a ? omidGlobal : a;
    })();
  new dc();
  var kc = new (function () {})(),
    lc = new (function () {})(),
    uc = new (function () {
      this.b = Y;
      this.a = L();
    })(),
    vc;
  M
    ? (vc =
        M.IntersectionObserver && (M.MutationObserver || M.ResizeObserver)
          ? new U(M, kc, uc, Y)
          : new S(M, lc, uc, ec, Y))
    : (vc = null);
  var Rb = vc,
    Sb = new (function () {
      var a = Y;
      var b = void 0 === b ? M : b;
      this.f = a;
      this.a = b;
      this.c = L();
      this.b = [];
    })(),
    Zb = new Qb();
  L();
  new Yb();
  if (M.frames && M.document && !("omid_v1_present" in M.frames)) {
    var wc;
    if ((wc = null == M.document.body)) wc = "MutationObserver" in M;
    wc
      ? jc()
      : M.document.body
      ? ic()
      : M.document.write(
          '<iframe style="display:none" id="omid_v1_present" name="omid_v1_present"></iframe>'
        );
  }
}.call(this, this));
